package com.example.threerivers.model;

public enum TransactionType {
    DEPOSIT,
    WITHDRAW
}
